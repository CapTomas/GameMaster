# Reading the file and creating counter of status codes
$file = Get-Content -Path "u_ex230530_x.log"
$counter = 0

# Looping through the file
foreach ($line in $file) {
        # Split line and check collumn 15; if it equals to 200, increment counter
        $columns = $line -split " "
        if ($columns[15] -eq "200") {
            $counter++
        }
    }

# Print the count of 200 status codes
Write-Host "$counter"